/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author aniru
 */
public class LocationModel {
    private String locationID;
    private String locName;
    private String locationCode;
    private String isAuction;
    private String customerID;
    private String addressStreet1;
    private String addressStreet2;
    private String city;
    private String state;
    private String postalCode;
    private String region;
    private String location_contact_name;
    private String locPhone;
    private String locFaxNumber;
    private String locEmail;

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    public String getLocName() {
        return locName;
    }

    public void setLocName(String locName) {
        this.locName = locName;
    }

    public String getLocationCode() {
        return locationCode;
    }

    public void setLocationCode(String locationCode) {
        this.locationCode = locationCode;
    }

    public String getIsAuction() {
        return isAuction;
    }

    public void setIsAuction(String isAuction) {
        this.isAuction = isAuction;
    }

    public String getCustomerID() {
        return customerID;
    }

    public void setCustomerID(String customerID) {
        this.customerID = customerID;
    }

    public String getAddressStreet1() {
        return addressStreet1;
    }

    public void setAddressStreet1(String addressStreet1) {
        this.addressStreet1 = addressStreet1;
    }

    public String getAddressStreet2() {
        return addressStreet2;
    }

    public void setAddressStreet2(String addressStreet2) {
        this.addressStreet2 = addressStreet2;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(String postalCode) {
        this.postalCode = postalCode;
    }

    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    public String getLocation_contact_name() {
        return location_contact_name;
    }

    public void setLocation_contact_name(String location_contact_name) {
        this.location_contact_name = location_contact_name;
    }

    public String getLocPhone() {
        return locPhone;
    }

    public void setLocPhone(String locPhone) {
        this.locPhone = locPhone;
    }

    public String getLocFaxNumber() {
        return locFaxNumber;
    }

    public void setLocFaxNumber(String locFaxNumber) {
        this.locFaxNumber = locFaxNumber;
    }

    public String getLocEmail() {
        return locEmail;
    }

    public void setLocEmail(String locEmail) {
        this.locEmail = locEmail;
    }
    
        public String toString() {
		return "locName=" + this.locName + " locEmail=" + this.locEmail + " AddressStreet1=" + this.addressStreet1 + " contactname="
				+ this.location_contact_name + " state=" + this.state;

    
}
}

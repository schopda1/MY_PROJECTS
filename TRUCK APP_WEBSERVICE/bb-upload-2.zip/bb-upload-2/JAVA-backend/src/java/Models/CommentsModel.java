/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Models;

/**
 *
 * @author schopda1
 */
public class CommentsModel {
    
    private String commentID;
    private String commentTime;
    private String comment;
    private String commentType;

    public String getCommentID() {
        return commentID;
    }

    public void setCommentID(String commentID) {
        this.commentID = commentID;
    }

    public String getCommentTime() {
        return commentTime;
    }

    public void setCommentTime(String commentTime) {
        this.commentTime = commentTime;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public String getCommentType() {
        return commentType;
    }

    public void setCommentType(String commentType) {
        this.commentType = commentType;
    }
    @Override
   public String toString() {
		return "commentID=" + this.commentID + " commentTime=" + this.commentTime + " comment=" + this.comment + " commentType="
				+ this.commentType ;
	}
}

    
    
    
  

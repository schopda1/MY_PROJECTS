-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 27, 2017 at 08:23 PM
-- Server version: 5.1.53
-- PHP Version: 5.3.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `truckapplication`
--

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `COMMENTID` varchar(20) NOT NULL,
  `COMMENTTIME` varchar(20) NOT NULL,
  `COMMENTS` varchar(20) NOT NULL,
  `COMMENTTYPE` varchar(20) NOT NULL,
  PRIMARY KEY (`COMMENTID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`COMMENTID`, `COMMENTTIME`, `COMMENTS`, `COMMENTTYPE`) VALUES
('C001', '01-05-2010', 'Regarding accounts d', 'CMNT1'),
('C002', '01-05-2017', 'Regarding data repli', 'CMNT12');

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE IF NOT EXISTS `customers` (
  `customerid` varchar(20) NOT NULL,
  `customerTitle` varchar(20) NOT NULL,
  `customername` varchar(20) NOT NULL,
  `businessName` varchar(20) NOT NULL,
  `billingAddress` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `stateOrProvince` varchar(20) NOT NULL,
  `postalCode` varchar(20) NOT NULL,
  `country` varchar(20) NOT NULL,
  `phoneNumber` varchar(20) NOT NULL,
  `cellNumber` varchar(20) NOT NULL,
  `otherNumber` varchar(20) NOT NULL,
  `faxNumber` varchar(20) NOT NULL,
  `emailAddress` varchar(20) NOT NULL,
  `customerType` varchar(20) NOT NULL,
  `companyName` varchar(20) NOT NULL,
  `alternateContactName` varchar(20) NOT NULL,
  `contactname` varchar(20) NOT NULL,
  `dateEntered` varchar(20) NOT NULL,
  PRIMARY KEY (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`customerid`, `customerTitle`, `customername`, `businessName`, `billingAddress`, `city`, `stateOrProvince`, `postalCode`, `country`, `phoneNumber`, `cellNumber`, `otherNumber`, `faxNumber`, `emailAddress`, `customerType`, `companyName`, `alternateContactName`, `contactname`, `dateEntered`) VALUES
('001', 'Mr', 'Sambhav', 'Oswal Info World ', '12b red cross road ', 'Nagpur', 'Maharashtra', '440001', 'INDIA', '2552647', '9766474406', '2541357', '2569885', 'oswal50@rediffmail.c', 'A', 'OSWPL', '123456', 'Sambhav Chopda', '01-01-2008'),
('002', 'Mrs', 'Helen', 'Dance Academy', '22nd block 23 street', 'New York', 'New York', '145895', 'United States', '2552647', '9766474406', '2541357', '2569885', 'helen@aol.com', 'B', 'D Company', '87513131', 'Helen ', '2-24-2009'),
('003', 'Mr', 'Zeshan', 'Oswal Info World ', '12b red cross road ', 'berlin', 'm.maryland', '60616', 'Germany', '6546161651', '6161616616', '6166164116', '4464', 'zsayed@gmail.com', 'A', 'OSWPL', '6548545', 'Sambhav Chopda', '12-12-2016');

-- --------------------------------------------------------

--
-- Table structure for table `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `employeeid` varchar(20) NOT NULL,
  `firstname` varchar(20) NOT NULL,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `extension` varchar(20) NOT NULL,
  `homephone` varchar(20) NOT NULL,
  `cellphone` varchar(20) NOT NULL,
  `jobtitle` varchar(20) NOT NULL,
  `socialsecuritynumber` varchar(20) NOT NULL,
  `driverlicensenumber` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `postalcode` varchar(20) NOT NULL,
  `birthdate` varchar(20) NOT NULL,
  `datehired` varchar(20) NOT NULL,
  `salary` varchar(20) NOT NULL,
  `notes` varchar(20) NOT NULL,
  PRIMARY KEY (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `employees`
--

INSERT INTO `employees` (`employeeid`, `firstname`, `lastname`, `email`, `extension`, `homephone`, `cellphone`, `jobtitle`, `socialsecuritynumber`, `driverlicensenumber`, `address`, `city`, `state`, `postalcode`, `birthdate`, `datehired`, `salary`, `notes`) VALUES
('521', 'Sanjay', 'Chopda', 'schopda1@gmail.com', '111', '31464616', '64646163', 'Driver', '8798652154', 'A20376777', 'sadar gandhi chowek ', 'Chicago', 'Illinois', '60616', '1989-04-22', '2012-11-11', '200000', 'new employee'),
('522', 'bob', 'marley', 'bm@aol.com', '13252', '54556985', '48946165', 'Helper', '654651', 'A20376888', 'downtoen overloop', 'Chicago', 'Illinois', '60616', '1992-08-12', '2015-12-12', '7500', 'old employee');

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE IF NOT EXISTS `expenses` (
  `expenseid` varchar(20) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `expensetype` varchar(20) NOT NULL,
  `purposeofexpense` varchar(20) NOT NULL,
  `amountspent` varchar(20) NOT NULL,
  `description` varchar(20) NOT NULL,
  `datepurchased` varchar(20) NOT NULL,
  `datesubmitted` varchar(20) NOT NULL,
  `advanceamount` varchar(20) NOT NULL,
  `paymentmethod` varchar(20) NOT NULL,
  PRIMARY KEY (`expenseid`),
  KEY `employeeid` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`expenseid`, `employeeid`, `expensetype`, `purposeofexpense`, `amountspent`, `description`, `datepurchased`, `datesubmitted`, `advanceamount`, `paymentmethod`) VALUES
('4456', '521', 'Employee Overall Dev', 'Expenses Travelling', '1000', 'Expenses given', '05-05-2005', '06-06-2005', '500', 'ToCheck'),
('5566', '522', 'Carriage', 'BillsOf Expenditure ', '20000', 'Car Rented', '12-12-2008', '12-12-2009', '5000', 'Mail Check Confirmat');

-- --------------------------------------------------------

--
-- Table structure for table `location`
--

CREATE TABLE IF NOT EXISTS `location` (
  `locationid` varchar(20) NOT NULL,
  `locname` varchar(20) NOT NULL,
  `locationcode` varchar(20) NOT NULL,
  `isauction` varchar(20) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `addressstreet1` varchar(20) NOT NULL,
  `addressstreet2` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `state` varchar(20) NOT NULL,
  `postalcode` varchar(20) NOT NULL,
  `region` varchar(20) NOT NULL,
  `location_contact_name` varchar(20) NOT NULL,
  `locphone` varchar(20) NOT NULL,
  `locfaxnumber` varchar(20) NOT NULL,
  `locemail` varchar(20) NOT NULL,
  PRIMARY KEY (`locationid`),
  KEY `customerid` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `location`
--

INSERT INTO `location` (`locationid`, `locname`, `locationcode`, `isauction`, `customerid`, `addressstreet1`, `addressstreet2`, `city`, `state`, `postalcode`, `region`, `location_contact_name`, `locphone`, `locfaxnumber`, `locemail`) VALUES
('C10', 'ORD', 'ORD10', 'YES', '002', 'bread and butter sto', '2154-A121324', 'Chicago', 'Active', '60616', 'Chicago', 'DriverA-madan', '3516465321', '65458121512', 'madan@gmail.com'),
('C11', 'NYC', 'NYC10', 'NO', '001', '2801 S', '05BWing', 'Chicago', 'Illinois', '60613', 'Chicago', '7/11 store owner', '255468521', '254135785', '711store@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE IF NOT EXISTS `orders` (
  `orderid` varchar(20) NOT NULL,
  `orderdate` varchar(20) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `truckid` varchar(20) NOT NULL,
  `isspecial` varchar(20) NOT NULL,
  `purchaseordernumber` varchar(20) NOT NULL,
  `ordertotalamount` varchar(20) NOT NULL,
  `transactionid` varchar(20) NOT NULL,
  `paymentid` varchar(20) NOT NULL,
  PRIMARY KEY (`orderid`),
  KEY `customerid` (`customerid`),
  KEY `employeeid` (`employeeid`),
  KEY `truckid` (`truckid`),
  KEY `transactionid` (`transactionid`),
  KEY `paymentid` (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`orderid`, `orderdate`, `customerid`, `employeeid`, `truckid`, `isspecial`, `purchaseordernumber`, `ordertotalamount`, `transactionid`, `paymentid`) VALUES
('1111', '04-04-2012', '001', '521', '101', 'NO', '225511', '12500', 'T1111', 'P1112'),
('1112', '03-05-2015', '002', '522', '102', 'YES', '225522', '50000', 'T1112', 'P11111');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE IF NOT EXISTS `payments` (
  `paymentid` varchar(20) NOT NULL,
  `paymentmethodid` varchar(20) NOT NULL,
  `paymentamount` varchar(20) NOT NULL,
  `paymentdate` varchar(20) NOT NULL,
  `checknumber` varchar(20) NOT NULL,
  `creditcard` varchar(20) NOT NULL,
  `creditcardnumber` varchar(20) NOT NULL,
  `cardholdersname` varchar(20) NOT NULL,
  `creditcardexpdate` varchar(20) NOT NULL,
  `creditcardauthorizationnumber` int(10) NOT NULL,
  PRIMARY KEY (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payments`
--

INSERT INTO `payments` (`paymentid`, `paymentmethodid`, `paymentamount`, `paymentdate`, `checknumber`, `creditcard`, `creditcardnumber`, `cardholdersname`, `creditcardexpdate`, `creditcardauthorizationnumber`) VALUES
('P11111', 'P1000', '12500', '2017-01-11', 'CHASU225ABC', '31454561541655515', '43402300190745215451', 'Mallik', '2019-06-12', 611),
('P1112', 'P1001', '2000', '02-02-2017', 'ITIL123456', '545456161656', '25417365126316', 'Subbulakshmi', '12-01-2023', 266);

-- --------------------------------------------------------

--
-- Table structure for table `pricing`
--

CREATE TABLE IF NOT EXISTS `pricing` (
  `priceid` varchar(20) NOT NULL,
  `locationidfrom` varchar(10) NOT NULL,
  `locationidto` varchar(10) NOT NULL,
  `price` varchar(20) NOT NULL,
  `locationcodefrom` varchar(10) NOT NULL,
  `locationcodeto` varchar(10) NOT NULL,
  `locationnamefrom` varchar(10) NOT NULL,
  `locationnameto` varchar(10) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  `paymentid` varchar(20) NOT NULL,
  PRIMARY KEY (`priceid`),
  KEY `customerid` (`customerid`),
  KEY `paymentid` (`paymentid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pricing`
--

INSERT INTO `pricing` (`priceid`, `locationidfrom`, `locationidto`, `price`, `locationcodefrom`, `locationcodeto`, `locationnamefrom`, `locationnameto`, `customerid`, `paymentid`) VALUES
('4456', 'CB2132', 'BC2312', '10000', 'ALS12', 'BOM12', 'Albino', 'Bombay', '001', 'P1112'),
('4466', 'ORD111', 'NAG112', '25000', 'XAC1', 'XAC2', 'Chicago', 'Nagpur', '002', 'P11111');

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `transactionid` varchar(15) NOT NULL,
  `priceid` varchar(20) NOT NULL,
  `transactiondate` varchar(20) NOT NULL,
  `transactiondescription` varchar(20) NOT NULL,
  `transactionamount` varchar(20) NOT NULL,
  `make` varchar(15) NOT NULL,
  `model` varchar(15) NOT NULL,
  `year` varchar(15) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `truckno` varchar(15) NOT NULL,
  `discount` varchar(15) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  `unitprice` varchar(20) NOT NULL,
  `driverpric` varchar(20) NOT NULL,
  `vin` varchar(20) NOT NULL,
  `runnumber` varchar(20) NOT NULL,
  `special` varchar(11) NOT NULL,
  `rate` varchar(20) NOT NULL,
  `surcharge` varchar(20) NOT NULL,
  `customerid` varchar(20) NOT NULL,
  PRIMARY KEY (`transactionid`),
  KEY `priceid` (`priceid`),
  KEY `custid` (`customerid`),
  KEY `customerid` (`customerid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `transactions`
--

INSERT INTO `transactions` (`transactionid`, `priceid`, `transactiondate`, `transactiondescription`, `transactionamount`, `make`, `model`, `year`, `employeeid`, `truckno`, `discount`, `quantity`, `unitprice`, `driverpric`, `vin`, `runnumber`, `special`, `rate`, `surcharge`, `customerid`) VALUES
('T1111', '4456', '2017-02-12', 'New', '15255', '2001', 'A101', '2001', '521', '10105', '0', '10', '10', '10', '31554653156', '10', 'NO', '10', '10', '001'),
('T1112', '4466', '2016-12-12', 'New', '40000', '2001', 'A102', '2001', '522', '102', '0', '10', '10', '10', '112201', '10', 'YES', '10', '10', '002');

-- --------------------------------------------------------

--
-- Table structure for table `trucks`
--

CREATE TABLE IF NOT EXISTS `trucks` (
  `truckno` varchar(20) NOT NULL,
  `make` varchar(20) NOT NULL,
  `year` varchar(20) NOT NULL,
  `model` varchar(20) NOT NULL,
  `licenseplateno` varchar(20) NOT NULL,
  `employeeid` varchar(20) NOT NULL,
  `color` varchar(20) NOT NULL,
  `vin` varchar(20) NOT NULL,
  `truckid` varchar(20) NOT NULL,
  PRIMARY KEY (`truckno`),
  KEY `employeeid` (`employeeid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `trucks`
--

INSERT INTO `trucks` (`truckno`, `make`, `year`, `model`, `licenseplateno`, `employeeid`, `color`, `vin`, `truckid`) VALUES
('101', '2001', '2001', 'A101', 'NY201', '521', 'RED', '12201', '2001111'),
('102', '2001', '2001', 'A102', 'NY202', '522', 'BLACK', '12202', '200112');

--
-- Constraints for dumped tables
--

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expensesempid` FOREIGN KEY (`employeeid`) REFERENCES `employees` (`employeeid`);

--
-- Constraints for table `location`
--
ALTER TABLE `location`
  ADD CONSTRAINT `loccustid` FOREIGN KEY (`customerid`) REFERENCES `customers` (`customerid`);

--
-- Constraints for table `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `ordcustid` FOREIGN KEY (`customerid`) REFERENCES `customers` (`customerid`),
  ADD CONSTRAINT `ordempid` FOREIGN KEY (`employeeid`) REFERENCES `employees` (`employeeid`),
  ADD CONSTRAINT `ordpaymentid` FOREIGN KEY (`paymentid`) REFERENCES `payments` (`paymentid`),
  ADD CONSTRAINT `ordtransid` FOREIGN KEY (`transactionid`) REFERENCES `transactions` (`transactionid`),
  ADD CONSTRAINT `ordtruckid` FOREIGN KEY (`truckid`) REFERENCES `trucks` (`truckno`);

--
-- Constraints for table `pricing`
--
ALTER TABLE `pricing`
  ADD CONSTRAINT `pricingcustid` FOREIGN KEY (`customerid`) REFERENCES `customers` (`customerid`),
  ADD CONSTRAINT `pricingpayment` FOREIGN KEY (`paymentid`) REFERENCES `payments` (`paymentid`);

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transcustid` FOREIGN KEY (`customerid`) REFERENCES `customers` (`customerid`),
  ADD CONSTRAINT `transprid` FOREIGN KEY (`priceid`) REFERENCES `pricing` (`priceid`);

--
-- Constraints for table `trucks`
--
ALTER TABLE `trucks`
  ADD CONSTRAINT `truckeid` FOREIGN KEY (`employeeid`) REFERENCES `employees` (`employeeid`);

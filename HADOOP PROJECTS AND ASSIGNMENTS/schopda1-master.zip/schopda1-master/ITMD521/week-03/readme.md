NOTE 1 : I have used *.java instead of all java files running seperately.
NOTE2 :  used ubuntu vanilla due to space problem
NOTE3 : all screenshots are there in analysis pdf file
NOTE 4 : for all the years there are some issues even though im uploading image of issue and will work on it .

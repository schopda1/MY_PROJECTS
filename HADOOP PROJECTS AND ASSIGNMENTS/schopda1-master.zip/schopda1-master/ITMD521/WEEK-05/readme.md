
I had DONE ALL THE PARTS
PREVIOUSLY I was UNABLE TO GO FOR ALL PUNCTUATION AND PREPOSITION BUT AFTER I SAW LINK THERE ARE 3 GIVEN PUNCTUATIONS 
$ bin/hadoop fs -cat /user/joe/wordcount/patterns.txt
\.
\,
\!
FROM LINK:-http://hadoop.apache.org/docs/current/hadoop-mapreduce-client/hadoop-mapreduce-client-core/MapReduceTutorial.html#Example:_WordCount_v2.0


HENCE ALL PART ARE DONE SUCCESSFULLY 
1>CREATED OP FOLDER
2>JAR FILE CREATED 
3>RUN O/P COMMAND WITH prefix /vagrant 
this creates a op folder in vagrant
then copied it to excel and picked TOP10 words AS PRESENTED TO OP DOCX FILES 
done

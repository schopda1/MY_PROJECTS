This image shows how shuffler works in MR jobs and is explained below
![shuffle](https://cloud.githubusercontent.com/assets/25092743/24327359/1c5c2ad4-1184-11e7-9c42-0fa23d18fc72.png)
This  section we use 3 file with extension  in .txt, .gzip and .bzip2 extension with combiner and without combiner.

Consider Example of  1990 in .txt , .gzip and .bzip2 extention with combiner and without combiner in prder to provide analysis depending upon the jobs runned on hadoop cluster.
Below is the analysis in a graphical form:
![item3part1](https://cloud.githubusercontent.com/assets/25092743/24328414/ffbad208-119d-11e7-9231-9fef4617106f.PNG)

1) Average Map time: txt file takes much less time as compared gz file bcz it maps it into only one map split where as bzip takes more time than txt.

2) Avearge Shuffle time :- average shuffle time of txt is larger than gz as gz does not requires much if the shiffling.

3) Avearge reduce time :- average reduce time is less for the gz as compared to txt and bzip bcz it requires reducing and merging of the tasks from maps fucntion.


Now with combiner:-
![item3part2](https://cloud.githubusercontent.com/assets/25092743/24328415/ffbc26da-119d-11e7-9cc7-717978172f8d.PNG)
 Analysis:-
 Average Map time:- average map is almost similar for txt with or without combiner bcz combiner fucntion doesnot comes in to picture before map funtion .but now after map funtion the combiner funtion takes the splits and combine it to reduce the volume and feeds it to the reduce funtion reducing the overall time. Also gz files has only one map and thus not taht effective in mapping but effective in copy phase.
 
 Average Shuffle time:- average shuffle time is optimized by the combiner function and thus reduces shuffle time respectively.
 
 Average Reduce time:- The reduce fucntion job is already half done by the combiner funtion and hence requires much less reduce time (mostly 0) when compared to without combiner files.

![7 1](https://cloud.githubusercontent.com/assets/25092743/24327523/4644c834-1188-11e7-8c94-3fbcaae28589.PNG)

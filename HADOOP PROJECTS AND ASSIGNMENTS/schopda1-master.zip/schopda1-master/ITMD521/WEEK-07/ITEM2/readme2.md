
ANALYSIS FOR ITEM 2
ITEM WITH COMBINER:
![item1wd combiners](https://cloud.githubusercontent.com/assets/25092743/24326952/2c6625d0-1178-11e7-9e79-971157356356.PNG)
As same as the item1 

![2 3](https://cloud.githubusercontent.com/assets/25092743/24327211/17f38784-1180-11e7-888c-f04f5ad26981.PNG)


 the files were created and executed with the help of new jar file. which contained combiner class. It is basically a program which reducts job of the reducers by lesening  the volume of data transfer between map splits and reduce process. 

From the above image we can say that 

So less work for copy phase .Hence  minimizing the time required to copy from the buffer to the disk.
Thus, in the graph of with combiner we can se that reduce time required is 0 means the files were combined and optimized by the combiner it self and feeded to reducer, Also the shuffle time reduces as the number of maps decreases which were  63maps.

Analysis:-

Average Map Time :- each task is splitted into input splits and then data goes to the reducers. We can interpret that it has 63 maps formed that means 63 input splits.It took 12,42,26 seconds for the maps to be allocated on diffrent nodes.

Average Shuffle Time :- Each it taken by the MapReduce programs to direct map tasks to correct reducers with the help of keys. We can interpret that shuffle time depends on the number of map splits formed and thus the shuffle time is directly proportional to the map splits. Average reduce time here is 69, 108 and 203 seconds.

Average Reduce Time : This is the total time required for the reduction process upon number of reduce tasks.Thus more number of splits more the time required for reducer.
In this image 
![7 1](https://cloud.githubusercontent.com/assets/25092743/24327347/adeedd4e-1183-11e7-8cc6-8d6634f3cf78.PNG)


STEP8 it take a lot of time for job allocation and running a job in cluster.

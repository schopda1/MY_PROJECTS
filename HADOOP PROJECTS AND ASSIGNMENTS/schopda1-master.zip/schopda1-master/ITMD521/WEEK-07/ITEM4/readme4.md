
We are using .gz extentions here which is non splitable .
So,map reduce funtion will not be able to split the map input to multiple maps thus increasing the map time, as whole input will be taken in to one map only.
This will require more space in cluster and resources which wil result in to out of memory error. Shown in image below  
![item4part1](https://cloud.githubusercontent.com/assets/25092743/24328240/d501a3f2-1198-11e7-9c99-4e6e540ccdcb.PNG)

1) Map time:- average map time will certainly increase also the overall elapse time will increase as map funtions does not splits the .gz extentions. 
Succedingly, that intermediate compression will work making it further compressed for reducing the shuffle time on disk due to small size of files transported.
This shows the working of  sort and copy phase.
 Map funtion will wait in order to find space and thus may take more time than other spliatble inputs.

2)  Shuffle time :-  There will be less shuffle time required as the whole input is mapped at once , now intermediate compression takes place and reduces the vomune of data to be transferred helping the process to reduce the shuffle time.
 It can be seen in the above image that shuffle time is ceratinly reduced as intermediate compression and no spliting comes into picture.

3)  Reduce time:- average reduce time will take his part in the total program as the compressed files has to be uncompressed.
Also there is no comniner to reduce the work of the reducer, thus it takes some time.

![item4part2](https://cloud.githubusercontent.com/assets/25092743/24328241/d930f838-1198-11e7-9bec-55055c06b80b.PNG)

1)  Map time:- when combiner comes in to picture it takes the input from the map funtion.
Compression takes place and then combiner plays its role to oprimize it even move further. 

2)  Shuffle time :- The average shuffle time and merge time is affected as there i only one map and one reducing task.
Combiner in the picture does the task of the reducer 

3)  Reduce time:- Average reduce time will take his part in the total program as the compressed files has to be uncompressed.
Also there is no comniner to reduce the work of the reducer, thus it takes some time.

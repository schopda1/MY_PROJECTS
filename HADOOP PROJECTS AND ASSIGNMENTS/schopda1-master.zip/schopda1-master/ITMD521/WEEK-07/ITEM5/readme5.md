
We are using .bz2 extention here Hence  spliatble So map reduce funtion will split the map input to multiple maps thus reducing the map time. The graph is as follows:-  
1)  Map time:-
 Average mapping  time will certainly decrease also the overall ealpse time will decrease as map funtions works splits the bz2 extentions ,
 Compression will work making it more compressed for reducing the shuffle time on disk due to small size. 
Here it shows the working of  sort phase and copy phase
![item5part1](https://cloud.githubusercontent.com/assets/25092743/24328225/9d7a5bb8-1198-11e7-9244-dade6447e186.PNG)
2) Shuffle time :- average shuffle time will ceratainly get affected due to intermediate compression and uncompression at the reducer but makin it more effective by reducing the volume of the dat transported.

3)  Reduce time:- average reduce time will take his part in the total program as the compressed files has to be uncompressed and also there is no comniner to reduce the work of the reducer,  thus This  takes some time.

After use of Combiner:-

1) Map time:- average map time will certainly decrease also the overall ealpse time will decrease as map funtions works splits the bz2 extentions. 
Here Compression will work making it further compressed for reducing the shuffle time on disk due to small size.
Here it shows the working of  sort phase and copy phase

So,  the combiner come in to picture which boosts up the reducer time making it more efficient.
This  will reduce the reduce and merge time resultantly.

2) Shuffle time :- average shuffle time minimizes as combiner comes ino picture and thus reduce times for shuffle as it does imtermediate compression and combiner bot helps in efficinecy

3)  Reduce time:- average reduce time will decrease as combiner does more than half task of the reducer and helps in efficinecy. Fro mthe picture above we can easily infer that how combiner affects the merge ,shuffle and reduce time. 
when compared to without combiner outputs.

The map output is written to disk and transferred across the network to the reducer nodes, by using a fast compressor such as LZO or Snappy, we can get performance gains simply because the volume of data to transfer is reduced.

Also , the intermediate compression helps the node manager to succesfully copy the resoursces  and starting from the  container due to less volume of data  being transfered
Shown below:

![item5part2](https://cloud.githubusercontent.com/assets/25092743/24328226/a24efeb4-1198-11e7-9057-9d318b09b188.PNG)

week7
ALL THE ANALYSIS PART ARE WRITTEN IN readme .md files for respective fiolders.
All codes are submitted as per requirement.

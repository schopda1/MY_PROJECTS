ANALYSIS FOR ITEM 6
MR And Chaning 
1) Average Map time: The time taken by the job is 38 seconds as tere in no fucntion before map function the value depends on the cluster resources.
2) Avearge Shuffle time :- the aveharge shuffletime taken is 514 seconds  and merge time is 90 seconds in the sorting phase when copied from the disk.
3) Avearge reduce time :- the time taken is 226 seconds becauseof the no of maps formed due to discrete MapReduce jobs.

Below is the analysis in a graphical form:
![item6](https://cloud.githubusercontent.com/assets/25092743/24328548/327f1200-11a1-11e7-806f-e2449472c696.PNG)


Using the dataset residing in the Hadoop Directory: /user/root/ncdc/90-93/  to execute two discrete Map
 1) Average Map time:-the avegarge map time depends on the cluster and it is around 18 seconds.
 2) Average Shuffle time:- the average shuffle time is certainly reduced to 283 seconds .
Also merge time is reduced to 97 seconds,
And  using multiple reducers in the chaining certainly reducing the copy , sort and merge phase time.
 3) Average Reduce time:- the reduce time is minimized as we are using two reducers and hence decreasing the overall elapse time of the job competlition.The reduced time is 105.

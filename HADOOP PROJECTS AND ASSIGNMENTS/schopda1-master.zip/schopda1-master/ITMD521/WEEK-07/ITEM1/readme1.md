ANALYSIS can be seen in th
is image link

![item1](https://cloud.githubusercontent.com/assets/25092743/24326778/824d8e5c-1173-11e7-9b6e-a2de50a2f527.PNG)

ANALYSIS can be seen in this image link

![item1](https://cloud.githubusercontent.com/assets/25092743/24326778/824d8e5c-1173-11e7-9b6e-a2de50a2f527.PNG)

For MaxTemperature without combiner
The cluster was working with 2 processors 16 GB and  memory of 450 GB storage and  6 nodes.

ITEM WITHOUT COMBINER:
1) size  =7.4 GB
Due to lack memory on cluster ,jobs were required to submit again as an when nodes released some memomory which can be tracked on history server.
 I re runned the jobs again and checked it from history server.
2) size  =16.47 GB 
When the size increased  it is more tough to find a space on cluster because users were using multiple vagrant boxes.
3) size  = 33.59 GB
From above  we can interpret that  time required to allocate resourses is the elapsed time which consist of ceratin denominations that are map time, reduce time, merge time and  shuffle time. 
Also the elapse time that is the time started when the job id was allocated resources is different from the time when job was run.
 
Analysis:-
1) Average Map Time :-  each task is splitted into input splits and then data goes to the reducers. 
We can interpret that it has  63 maps formed that means 63 input splits.It took 10,34 and 25 seconds for the maps to be allocated on diffrent nodes. 
2) Average Shuffle Time :- Each it  taken by the MapReduce programs to direct map tasks to correct reducers with the help of keys. 
We can interpret that shuffle time depends on the number of map splits formed and thus the shuffle time is directly proportional to the map splits. Average reduce time here is 55, 90 and 146 seconds.
3) Average Reduce Time : This is the total time required for the reduction process upon number of reduce tasks.Thus more number of splits more the time required for reducer.

![2 3](https://cloud.githubusercontent.com/assets/25092743/24327211/17f38784-1180-11e7-888c-f04f5ad26981.PNG)

In this image 
![7 1](https://cloud.githubusercontent.com/assets/25092743/24327347/adeedd4e-1183-11e7-8cc6-8d6634f3cf78.PNG)


STEP8 it take a lot of time for job allocation and running a job in cluster.

Run the sample code job provided by the book
But this time insert three addition records that look like this:
NULL, 'Widget', 0.87, '2010-02-25', 1, 'Connects Gizmos'


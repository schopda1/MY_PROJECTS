It should contain a ReadMe.md file with the screenshot of a sucessful output of: sqoop help command



SOLUTION:-
![image](https://cloud.githubusercontent.com/assets/25092743/24730901/1b534b4e-1a2c-11e7-986e-a0f319b8ea23.png)


CREATE A DATABASE "WEEK2"
CREATE A TABLE SAM_FTABLE WITH GIVEN SQL SCRIPT
NOW USE JAVA FILE IN ~
EXECUTE COMMAND javac javafilename.java 
java -Xmx2048m javafilename

SEE OUTPUT
Thanks for your effort

public class Connect { 

	
private static Connection connection;
	
    private static String url = "jdbc:mysql://localhost/week2";
    private static String username = "root";
    private static String password = "password";

    public static Connection connect(){
        try{
            Class.forName("com.mysql.jdbc.Driver").newInstance();
        }catch(ClassNotFoundException cnfe){
            System.err.println("Error: "+cnfe.getMessage());
        }catch(InstantiationException ie){
            System.err.println("Error: "+ie.getMessage());

        }

        connection = DriverManager.getConnection(url,username,password);
        return connection;
    }
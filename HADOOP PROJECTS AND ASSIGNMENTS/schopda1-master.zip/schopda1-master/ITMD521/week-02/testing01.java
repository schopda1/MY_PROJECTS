import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.util.ArrayList;
import java.util.zip.GZIPInputStream;
import java.util.zip.GZIPOutputStream;
import java.sql.*;
import java.util.Calendar;

public class testing01 {
	public static void main(String[] args) throws Exception {
		
 String myDriver = "org.gjt.mm.mysql.Driver";
	     String myUrl = "jdbc:mysql://localhost/week2?autoReconnect=true&useSSL=false";
	     Class.forName(myDriver);
	     Connection conn = DriverManager.getConnection(myUrl, "root", "password");
	    	String temp;
		FileInputStream filezip = new FileInputStream("/home/ubuntu/all/1990.gz");
		GZIPInputStream gzipper = new GZIPInputStream(filezip);
	
		Reader decoder = new InputStreamReader(gzipper);
		BufferedReader br = new BufferedReader(decoder);
		String line;
		while((line  = br.readLine()) != null){
	
		
	String year = line.substring(15,19);
		if(line.charAt(87) == '+')
		{
			 temp =  line.substring(88, 92);
		}else
		{
		
		 temp =  line.substring(87, 92);

		}
		String qc3= line.substring(92,93);
		String wthr_id = line.substring(4,9);
		if( temp != "9999" && qc3.matches("01459")){
		temp =  line.substring(88, 92);
		}
		String weaban= line.substring(10,15);
		String date= line.substring(14,22);
		String hour= line.substring(23,27);
		String unknown= line.substring(27,28);
		String lati= line.substring(28,34);
		String longi= line.substring(34,41);
		String unknown1= line.substring(41,46);
		String elevation= line.substring(46,51);
		String phval1= line.substring(51,56);
		String phval2= line.substring(56,61);
		String wind= line.substring(61,64);
		String qc1= line.substring(63,64);
		String phval3= line.substring(64,65);
		String phval4= line.substring(65,69);
		String phval5= line.substring(69,70);
		String phval6= line.substring(70,71);
		String skyceil= line.substring(71,76);
		String phqc= line.substring(76,77);
		String phval7= line.substring(77,78);
		String visiblity= line.substring(78,84);
		String qc2= line.substring(84,85);
		String phval8= line.substring(85,86);
		String phval9= line.substring(86,87);
		String dew_point= line.substring(93,98);
		String qc4= line.substring(98,99);
		String atm_pressure= line.substring(99,104);
		String qu5= line.substring(104,105);
		String query = "INSERT into  sam_testtable( temp,wthr_id ,year,  Date, hour, unknown, lati, longi,weaban, unknown1,  phval1, phval2, wind, qc1, phval3, phval4, phval5, phval6, skyceil, phqc, phval7, visibility,elevation, qc2, phval8, qc3, dew_point, qc4, atm_pressure, qu5,  phval9) values (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);";
		PreparedStatement preparedStmt = conn.prepareStatement(query);
		 preparedStmt.setString (1, year);
	     preparedStmt.setString (2, wthr_id);
	     preparedStmt.setString (3, weaban);
	     preparedStmt.setString (4, date);
	     preparedStmt.setString (5, hour);
	     preparedStmt.setString (6, unknown);
	     preparedStmt.setString (7, lati);
	     preparedStmt.setString (8, longi);
	     preparedStmt.setString (9, unknown1);
	     preparedStmt.setString (10, elevation);
	     preparedStmt.setString (11, phval1);
	     preparedStmt.setString (12, phval2);
	     preparedStmt.setString (13, wind);
	     preparedStmt.setString (14, qc1);
	     preparedStmt.setString (15, phval3);
	     preparedStmt.setString (16, phval4);
	     preparedStmt.setString (17, phval5);
	     preparedStmt.setString (18, phval6);
	     preparedStmt.setString (19, skyceil);
	     preparedStmt.setString (20, phqc);
	     preparedStmt.setString (21, phval7);
	     preparedStmt.setString (22, visiblity);
	     preparedStmt.setString (23, qc2);
	     preparedStmt.setString (24, phval8);
	     preparedStmt.setString (25, qc3);
	     preparedStmt.setString (26, dew_point);
	     preparedStmt.setString (27, qc4);
	     preparedStmt.setString (28, atm_pressure);
	     preparedStmt.setString (29, qu5);
	     preparedStmt.setString (30, temp);
	     preparedStmt.setString (31, phval9);
	     preparedStmt.executeUpdate();
		}
	}
}



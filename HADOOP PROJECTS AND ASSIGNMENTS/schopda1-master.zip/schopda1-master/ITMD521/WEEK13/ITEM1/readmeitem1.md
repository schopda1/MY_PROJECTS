FOR ITEM 1
QUESTION AS PER BB
Write a Map Reduce Job (Java Classes to find)  (You can use Reducers, Chaining, or any other topic we covered)
the most frequently visted WebPage (URL) with a 200 return code that is not index.* per month
the most frequently visted WebPage (URL) with a 200 return code that is not index.* per day
Create a ReadMe.md file with your answers and any assumptions made during the job run

**********************************************************************************************************
OUTPUTS -PART1 for per month 
![week13item1](https://cloud.githubusercontent.com/assets/25092743/25552602/02e6b396-2c53-11e7-9e4f-22df7adad442.PNG)

![urlsmallpm](https://cloud.githubusercontent.com/assets/25092743/25561077/3d1b2f40-2d18-11e7-8902-b53da1262476.PNG)


File1:SamUlog.java,SamMapping.java,SamReducer.java
**************************************************************************************************************
OUTPUTS -PART2 for per day

![week13item2-1](https://cloud.githubusercontent.com/assets/25092743/25552832/e068eb76-2c58-11e7-942e-05b735facdc2.PNG)

![week13item2-2](https://cloud.githubusercontent.com/assets/25092743/25552837/e4153446-2c58-11e7-93a2-8b9276e032eb.PNG)

![week13item2-3](https://cloud.githubusercontent.com/assets/25092743/25552840/e6d9270a-2c58-11e7-8dba-b4a6435be443.PNG)


![week13item2-4](https://cloud.githubusercontent.com/assets/25092743/25552841/e9ce5cb4-2c58-11e7-9ad2-85051e31d213.PNG)

FileName:SamUrlPday.java,UrlSamRed.java,URLSampday.java
*****************************************************************************************************************
***Analysis***
Here I used substring technique to reduce it to map but is not so effective if it gets complex.For getting months it was not so effective for Mapper to Reducer.While fetching url it tconsumed time.
So,Infering 
The average mapping time is as it has created 25 maps in log files and single running job on cluster was there.The performance was very efficent and was very fast but while running in a large cluster ,number of maps increased  and even shuffle timing and reducing time was good.
Using a combiner and mapping will surely improve timings of the jobs.

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SamUrlPday
  extends Mapper<LongWritable, Text, Text, Text> {
 @Override
  public void Mapping(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
String line = value.toString();
String month, quality, URL;
try{
       month = line.substring(5, 10);
      quality = line.substring(123, 126);
    if (quality.matches("200")) {
    	 URL = line.substring(39, 50);
   context.write(new Text(month), new Text(URL));  
}
}
catch(StringIndexOutOfBoundsException ex){
	 month = " ";
	 URL =" ";
	 quality = " ";
}
}
}

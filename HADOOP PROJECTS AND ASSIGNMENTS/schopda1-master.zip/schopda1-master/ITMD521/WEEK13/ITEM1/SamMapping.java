import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

public class SamMapping
  extends Mapper<LongWritable, Text, Text, Text> {

  private static final int MISSING = 9999;
  
  @Override
  public void map(LongWritable key, Text value, Context context)
      throws IOException, InterruptedException {
    
    String line = value.toString();
    String[] a = line.split(" ");
    String[] date;
	String month, quality, URL ;
	try{
		if ( !(((a[0].equals("#Software:"))) || ((a[0].equals("#Version:"))) || ((a[0].equals("#Date:"))) || ((a[0].equals("#Fields:")))))
		{date = a[0].split("-");
		   month = date[1];
		  quality = a[10];
		if (quality.equals("200")) {
			 URL = a[4];
	   if(!(URL.matches("index.*")))
	   context.write(new Text(month), new Text(URL));  
		}
	}
	}
	catch(StringIndexOutOfBoundsException ex){
		 month = " ";
		 URL =" ";
		 quality = " ";
	}
  }
}

WEEK 13 final project 
Objectives

Display understanding of the Hadoop Ecosystem
Display an understadning of how to use and process data using Sqoop
Display an understanding of writing MapReduce Jobs
Display an understanding of using the HIVE metastore and writing HIVEQL queries
Display an understanding of using Pig and writing Pig Latin queries
Show and understanding of the use of standard MySQL based SQL queries


*****************************************************************************************************
ITEM1 done  // stuck on some error with working on Item 2 and 3 //half way for item4//

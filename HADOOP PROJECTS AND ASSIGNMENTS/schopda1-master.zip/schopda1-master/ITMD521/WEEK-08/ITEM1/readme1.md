
1) Item 90and92-256(without combiner) without intermediate compression with .txt, .bz2 and .gz extension:
![8-1](![screen shot 2017-04-05 at 10 17 58 am](https://cloud.githubusercontent.com/assets/25092743/24712754/55ab0702-19e9-11e7-8b0c-14f13728d10d.png))

In this we are using dataset without combiner and intermediate compression .So, it will effect on the shuffling process   as well as on the reducing  time of the MapReduce process. 
By analyzing  the screen shot we can easily infer the following results.
Analysis:-

Average Map time: txt file takes less time as compared to gz and bz2. 
As gz takes only one map to enter into the process as it is uns-plitable.
 Also bz takes 5 maps and it does not provide performances by splitting in to only 5 splits.

Average Shuffle time :- average shuffle time of txt is larger than gz as gz does not requires much of the shuffling because of one map. 
So, shuffle time depends on number of maps. 
Similarly bz2 w requires equivalent time as there are only 5 splits.

Average reduce time :- average reduce time is more for the gz as compared to txt and bzip because  there is a large file in the buffer to be reduced.

 
 
2) Item 90and92-256(with combiner) without intermediate compression with .txt, .gz, .bz2 extension:
![8-2](![screen shot 2017-04-05 at 10 19 59 am](https://cloud.githubusercontent.com/assets/25092743/24712799/7d0bf428-19e9-11e7-987b-541378d6ae8e.png))
Analysis:-

Average Map time: test file takes less time  as compared to gz and bz2. 
As gz takes only one map to enter into the process as it is un-splittable. 
Also ,bz takes 5 maps and it does not provide performances by splitting in to only 5 splits.

Average Shuffle time :- average shuffle time of txt and bz2 is larger than gz as gz does not requires much of the shuffling because  of one map and combiner reducing the shuffle time even more.
As combiner comes into picture shuffle time reduces for every extension

Average reduce time :- average reduce time reduces close to zero because half of the job is done by the combiner. 

  
  
3) Item 90and93-256(without combiner) without intermediate compression with .txt, .gz, .bz2 extension:

![8-11](![screen shot 2017-04-05 at 10 21 06 am](https://cloud.githubusercontent.com/assets/25092743/24712851/a1281300-19e9-11e7-8d23-7a30a651d55b.png)
)
Analysis:-

Average Map time: The map time of .txt reduces as 135maps are formed 
As the size of the input files increases the map time increases as well as map splits increases for .bz2. Gz has only one map.

Average Shuffle time :- As it is without combiner increase in map splits increases shuffle time  without combiner affects the time resulting in to affecting the performance. 
Gz requires minimum shuffle time as their  is only one map formed.

Average reduce time :- average reduce time is more for the gz as compared to txt and bzip because  there is a large file in the buffer to be reduced.

   
   
   
4) Item 90and92-256(with combiner) without intermediate compression with .txt, .gz, .bz2 extension:
![8-22](![screen shot 2017-04-05 at 10 22 16 am](https://cloud.githubusercontent.com/assets/25092743/24712907/ca7ef106-19e9-11e7-8510-30209616c4ed.png)
)

Analysis:-

Average Map time: The map splits increases and shuffle time decreases with the help of combiner . As the size of the input files increases the map time increases as well as map splits increases for .bz2. Gz has only one map.

Average Shuffle time :- as it is without combiner increase in map splits increases shuffle time that too without combiner affects the time resulting in to affecting the performance. Gz requires minimum shuffle time as thier is only one map formed.

Average reduce time :- average reduce time is more for the gz as compared to txt and bzip because  there is a large file in the buffer to be reduced.





5) Item 90and92-256 (without combiner) with intermediate compression with .gz extension VS Item 90and92-256 (with combiner) with intermediate compression with .gz extension :
![8-111](![screen shot 2017-04-05 at 10 24 24 am](https://cloud.githubusercontent.com/assets/25092743/24713026/14ec684a-19ea-11e7-8967-8b3a1f0af10d.png))

Analysis:
Intermediate compression certainly reduces the shuffle time by reducing the volume of the data to be shuffled. Also it is a gz file so only one map and use of combiner with intermediate increases the time of map function, affecting the performance.



6) Item  90and93-256(without combiner) with intermediate compression with .gz extension VS Item 90and93-256 (with combiner) with intermediate compression with .gz extension:
![8-112](![screen shot 2017-04-05 at 10 25 20 am](https://cloud.githubusercontent.com/assets/25092743/24713084/3a4f80fe-19ea-11e7-8432-7b045ed3af77.png))


Similarly ,for this analysis : 

1> the use of combiner with intermediate compression
2> increases the average Map time for splits.





7) Item 90and92-256 (without combiner) with intermediate compression with .bz2 extension VS Item 90and92-256 (with combiner) with intermediate compression with .bz2 extension :
![8-1111](![screen shot 2017-04-05 at 10 26 46 am](https://cloud.githubusercontent.com/assets/25092743/24713162/69166fec-19ea-11e7-9ebf-8c25fec4db04.png))

Analysis :
Here the use of combiner with intermediate compression affects the overall time of the MapReduce function, as it takes much longer time by combiners to reduce the volume of the files. thus making the whole process slow and affects the performance.



8) Item  90and93-256(without combiner) with intermediate compression with .bz2 extension VS Item 90and93-256 (with combiner) with intermediate compression with .bz2 extension :
![8-1112](![screen shot 2017-04-05 at 10 27 40 am](https://cloud.githubusercontent.com/assets/25092743/24713197/8968dd98-19ea-11e7-9dd9-f0ca29bb9dc9.png))


Similarly as the data increases and combiner does not makes much different on the total time rather it increases the overall time.

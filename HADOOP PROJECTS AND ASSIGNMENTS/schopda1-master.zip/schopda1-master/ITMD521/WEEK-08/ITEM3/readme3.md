
In combiner class ,we can create combiner class for Min_MAX and Average because combiners can be used only on that functions for which the calculation is increasing the  means SUM, AVG, Min and MAX. 
If the calculation is not increasing  then combiner fucntion don't reduces the job of the reducer , Hence  reducer will be required  to reduce fucntion.
Also there they may reduce the shuffle time between mapper and  reducer.

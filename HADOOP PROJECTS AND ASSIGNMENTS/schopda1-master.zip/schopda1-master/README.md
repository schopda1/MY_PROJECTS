# schopda1
ITM Private Repo Sambhav Chopda
![fullsizerender](https://cloud.githubusercontent.com/assets/25092743/22312430/625c41f8-e31d-11e6-8479-f1b366f6ed12.jpg)
Hi I’m SAMBHAV CHOPDA from Nagpur( center of India ) Maharashtra  
I have done my bachelors  in Computer Science and has a work experience of 1 year in a startup firm as a software developer and other two firms as a post of Technical Adviser (advising companies and their clients for recent technologies up gradation ).
I have interest in DB development and analytics .
I love to learn new things and has interest  hobbies as cooking and photography.
